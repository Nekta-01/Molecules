---
name: state-management
description: Track agent state across iterations - plan, subtasks, observations, test results, and strategy changes.
license: MIT
metadata:
    skill-author: Based on Ninja (unconst/ninja)
---

# State Management

## Overview

Track your progress and context across multiple iterations. The state object maintains:
- **plan**: High-level strategy
- **subtasks**: Individual tasks with files, status, results
- **observations**: Key findings
- **test_results**: Summary, pass/fail counts
- **iteration**: Current iteration number
- **strategy_changes**: What changed and why

## State Schema

```json
{
  "plan": "Refactor authentication to use JWT tokens",
  "subtasks": [
    {
      "id": 1,
      "desc": "Update user model to include JWT fields",
      "files": ["models/user.py"],
      "status": "done",
      "result": "Added fields successfully"
    },
    {
      "id": 2,
      "desc": "Update login endpoint to issue tokens",
      "files": ["routes/auth.py"],
      "status": "in_progress",
      "result": null
    }
  ],
  "observations": [
    "Old auth uses sessions, not compatible with mobile",
    "JWT library already installed"
  ],
  "test_results": {
    "summary": "3/5 tests passing",
    "pass": 3,
    "fail": 2
  },
  "iteration": 3,
  "strategy_changes": [
    "Switched from session-based to JWT after observation 1"
  ]
}
```

## When to Use

- **Multi-iteration tasks** - remember where you are
- **Complex refactoring** - track which files changed
- **Debugging** - record what you tried and what worked
- **Team handoff** - state shows progress clearly

## Operations

### Read State
```bash
cat ~/.agent_state.json
```

### Update State (merge)
```bash
# Add observation
cat ~/.agent_state.json | jq '.observations += ["Found memory leak in cache"]' > /tmp/new_state
mv /tmp/new_state ~/.agent_state.json
```

### Replace State
```bash
echo '{"plan": "...", "subtasks": []}' > ~/.agent_state.json
```

## Key Principles

1. **Merge not replace** - preserve existing context
2. **Record observations** - capture key findings
3. **Track iterations** - know how many attempts
4. **Document strategy** - why you changed approach

## Why It Works

- **Survives context limits** - external file, not in-context
- **Structured** - easy to query and update
- **Rich context** - observations, results, strategy all tracked
- **Enables recovery** - can resume from any state