---
name: anti-hallucination
description: Directives to prevent common agent failure modes - editing wrong files, fabricating code, ignoring test failures.
license: MIT
metadata:
    skill-author: Based on Ninja (unconst/ninja)
---

# Anti-Hallucination Directives

## Overview

Patterns discovered through 100+ experiments that reduce agent failures:
1. **Anti-fabrication** - don't edit substitute files
2. **Signature preservation** - don't change function signatures
3. **Test validation** - don't ignore failing tests
4. **Anti-analysis paralysis** - don't overthink, take action

## The Competence Cliff

Through automated experiments, Ninja discovered:
- **4-6 bugs** = cliff for interconnected fixes
- **4 files / 6 endpoints** = cliff for code construction
- **2 modules** = cliff for refactoring

**Key insight**: It's interconnection, not complexity, that breaks agents.

## Anti-Fabrication Directive

### Problem
Agent edits wrong file as a substitute for the actual target.

### Directive
> "Never edit a different file as a substitute for the target file. If you're unsure which file to edit, use search to find the exact file. Do not make up file names or edit files you haven't verified exist."

### Detection
- Log each file edit
- Verify edit target matches intent
- Flag when agent edits unexpected file

## Signature Preservation Directive

### Problem  
Agent changes function signatures during refactoring, breaking callers.

### Directive
> "When modifying functions, preserve the original signature (name, parameters, return type). If signature must change, update all call sites first and document the change."

### Detection
- Compare function signatures before/after
- Check all call sites still valid
- Flag signature changes

## Test Validation Directive

### Problem
Agent ignores failing tests or marks them as "expected to fail."

### Directive
> "Tests are the source of truth. If tests fail after your change, the change is wrong - not the tests. Do not modify tests to pass. Fix your code instead."

### Detection
- Require all tests pass before considering done
- Track test pass rate changes
- Flag when tests are modified to pass

## Anti-Analysis Paralysis Directive

### Problem
Agent spends too long analyzing, never takes action.

### Directive
> "After 3 failed attempts to solve a problem, you MUST try a different approach. Do not repeat the same failed strategy. If stuck, use the oracle tool for a second opinion."

### Detection
- Track attempts per problem
- Detect repeated patterns
- Prompt strategy change after threshold

## Test Gaming Prevention

### Problem
Agent writes tests that always pass regardless of code.

### Directive
> "Tests must be falsifiable - they must be able to fail if the code is wrong. Tests that always pass provide no value. Test the actual behavior, not just that code runs."

### What Makes a Good Test
- Can fail if implementation is wrong
- Tests behavior, not implementation
- Has meaningful assertions
- Covers edge cases

## Summary Checklist

Before considering a task done:
- [ ] Did you edit the correct file?
- [ ] Did you preserve function signatures?
- [ ] Did all tests pass?
- [ ] Did you try a different approach if stuck?
- [ ] Are your tests actually testing behavior?