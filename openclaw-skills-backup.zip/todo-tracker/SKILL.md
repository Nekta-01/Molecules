---
name: todo-tracker
description: Structured task tracking for multi-step coding tasks. Track progress with content, activeForm, and status (pending/in_progress/completed).
license: MIT
metadata:
    skill-author: Based on Ninja (unconst/ninja)
---

# Todo Tracker

## Overview

Keep track of multi-step tasks with structured todo lists. Each todo has:
- **content**: Task description in imperative form (e.g., "Fix authentication bug")
- **activeForm**: Present continuous form (e.g., "Fixing authentication bug")
- **status**: pending | in_progress | completed

## When to Use

- Multi-file refactoring tasks
- Bug fixes spanning multiple components
- Feature implementations with several steps
- Any task where you might lose track of progress

## Best Practices

1. **Write the full list each time** - not just changes
2. **Use imperative form** - "Fix X", not "Fixing X" for content
3. **Mark in_progress** - when you start working on a task
4. **Update completed** - when done, with brief result

## Example Todo List

```json
[
  {
    "content": "Identify the bug in user authentication",
    "activeForm": "Identifying the bug in user authentication",
    "status": "completed"
  },
  {
    "content": "Fix null pointer in login handler",
    "activeForm": "Fixing null pointer in login handler", 
    "status": "in_progress"
  },
  {
    "content": "Add test for login edge case",
    "activeForm": "Adding test for login edge case",
    "status": "pending"
  }
]
```

## CLI Usage

```bash
# Read current todos
cat ~/.todo_state.json

# Write updated todos  
echo '[{"content": "Fix bug", "status": "in_progress"}]' > ~/.todo_state.json
```

## Why It Works

- **External state** - survives context compaction
- **Structured format** - easy to parse and update
- **Human readable** - activeForm shows progress clearly
- **Forces planning** - you must articulate each step