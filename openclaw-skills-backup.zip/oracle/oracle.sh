#!/bin/bash
# Oracle - Get a second opinion from a different AI model

usage() {
    echo "Usage: oracle \"your question\" [code_context]"
    echo ""
    echo "Get a second opinion from a different AI model."
    echo "Useful when stuck, unsure about approach, or want to verify understanding."
    exit 1
}

if [ -z "$1" ]; then
    usage
fi

QUESTION="$1"
CODE_CONTEXT="${2:-}"

# Get API key
API_KEY="${OPENROUTER_API_KEY:-${ANTHROPIC_API_KEY:-}}"
if [ -z "$API_KEY" ]; then
    echo "Error: OPENROUTER_API_KEY or ANTHROPIC_API_KEY required"
    exit 1
fi

# Build the prompt
PROMPT="You are an oracle providing a second opinion. You see the user's question and code context, but NOT their conversation history.

Question: $QUESTION"

if [ -n "$CODE_CONTEXT" ]; then
    PROMPT="$PROMPT

Code context:
\`\`\`
$CODE_CONTEXT
\`\`\`"
fi

PROMPT="$PROMPT

Provide a focused, helpful response. Include:
1. What's likely wrong
2. Specific suggestions for next steps
3. Code snippets if helpful

Be direct - don't be overly cautious. The user needs actionable advice."

# Call OpenRouter (use a different model than default)
MODEL="${ORACLE_MODEL:-anthropic/claude-sonnet-4-20250514}"

curl -s "https://openrouter.ai/api/v1/chat/completions" \
    -H "Authorization: Bearer $API_KEY" \
    -H "Content-Type: application/json" \
    -H "HTTP-Referer: https://openclaw.ai" \
    -H "X-Title: Oracle" \
    -d "{
        \"model\": \"$MODEL\",
        \"messages\": [{\"role\": \"user\", \"content\": $PROMPT}],
        \"max_tokens\": 1000
    }" | python3 -c "
import sys, json
data = json.load(sys.stdin)
if 'choices' in data:
    print(data['choices'][0]['message']['content'])
elif 'error' in data:
    print('Error:', data['error'])
else:
    print(json.dumps(data, indent=2))
"