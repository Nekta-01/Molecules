---
name: oracle
description: Get a second opinion from a different AI model. Use when stuck, unsure about approach, or want to verify understanding of complex code. The oracle sees your question but NOT your conversation history, so include all relevant context.
license: MIT
metadata:
    skill-author: Based on Ninja (unconst/ninja)
---

# Oracle - Second Opinion Tool

## Overview

The oracle tool gets a second opinion from a different AI model. It's like asking a colleague for help when you're stuck - you explain the problem, show relevant code, and get a fresh perspective.

## When to Use

- **Stuck on a bug** - can't figure out why it's failing
- **Unsure about approach** - multiple ways to solve, don't know which is best
- **Complex codebase** - new code patterns you don't understand
- **Verification** - want to double-check your fix before committing
- **Writer's block** - can't figure out what to write next

## How It Works

1. You provide:
   - Your question with all necessary context
   - Relevant code snippets
   - What you've tried so far

2. The oracle uses a **different model** than your main agent
   - This ensures fresh perspective, not echo chamber
   - Default: Claude Sonnet via OpenRouter

3. You get a second opinion to help you proceed

## Best Practices

- **Include all context** - the oracle doesn't see your conversation history
- **Keep questions focused** - oracle has limited context window
- **Show what you tried** - helps oracle understand what's not working
- **Ask about specific things** - "why does X fail?" not "fix everything"

## Environment Variables

```bash
# Required for oracle to work
OPENROUTER_API_KEY=your-key

# Optional: customize oracle model
ORACLE_MODEL=anthropic/claude-sonnet-4-6

# Optional: use different provider
ANTHROPIC_API_KEY=your-key
```

## Example Usage

```
User: The oracle tool should help me debug this Python error

Oracle response: The error "TypeError: 'NoneType' object is not subscriptable" 
suggests you're trying to access index [0] on a None value. This typically 
happens when:
1. A function returns None instead of expected list
2. API response failed but code didn't check for None
3. Database query returned empty result

Looking at your code:
- The `get_users()` function can return None if DB fails
- You call `users[0]` without checking if users is None

Fix: Add null check: `if users and users[0]:`
```

## Why It Works

- **Different model** = different training data, different biases
- **Fresh context** = doesn't carry forward incorrect assumptions
- **Focused prompt** = forces you to articulate the problem clearly
- **Breaks loops** - agents can get stuck in failed approaches, oracle breaks the loop